"""Real_Estate URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('',views.welcome,name='welcome'),
    path('login/',views.login,name='login'),
    path('register/',views.register,name='register'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('password_reset/',views.password_reset,name='password_rest'),
    path('password_reset_done/',views.password_reset_done,name='password_reset_done'),
    path('password_reset_form/',views.password_reset_form,name='password_reset_form'),
    path('password_reset_sent/',views.password_reset_sent,name='password_reset_sent'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('feedback/',views.feedback,name='feedback'),
    path('help/',views.help,name='help'),
    path('homepage/',views.homepage,name='homepage'),
    path('transaction/',views.transaction,name='transaction'),
    path('land/',views.land,name='land'),
    path('commercial/',views.commercial,name='commerical'),
    path('development/',views.development,name='development'),
    path('industrial/',views.industrial,name='industrail'),
    path('property_management/',views.property_management,name='property_management'),
    path('villa/',views.villa,name='villa'),
    path('details/',views.details,name='detaisl'),
    path('admin/', admin.site.urls),
]
